<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AwardProject extends Model
{
    protected $guarded = array();
    protected $table = 'award_projects';
}
