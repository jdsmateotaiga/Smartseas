<div class="d-n@sm- peer peer-greed h-100 pos-r bgr-n bgpX-c bgpY-c bgsz-cv" style="background-image:url({{URL::to('/')}}/assets/static/images/bg.jpg)">
<div class="pos-a centerXY">
    <div class="bgc-white bdrs-50p pos-r"><img class="pos-a centerXY" src="{{URL::to('/')}}/images/smartseas-logo.jpg" alt=""></div>
</div>
</div>