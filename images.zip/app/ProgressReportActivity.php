<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgressReportActivity extends Model
{
    //
    protected $guarded = array();
    protected $table = 'progress_report_activities';
}
