<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgressReportOutput extends Model
{
    //
}
